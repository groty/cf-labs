package org.davidlindkvist.websocket;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

public class SmartChatServiceServlet extends ChatServiceServlet implements Servlet 
{
	private static final long serialVersionUID = 2010031501L;
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		long latestMessage = getRequestTimestamp(req, "latestMessageID");
		
		if(latestMessage < 0)
			latestMessage = getRequestTimestamp(req, "currentRequest");	
		
		res.setContentType("text/html;charset=utf-8");
		res.getWriter().write( getMessagesAsJSON(latestMessage) );
	}
	
	protected String getMessagesAsJSON(long latestMessage) 
	{
		JSONArray msgs = new JSONArray();
		for(ChatMessage msg : echoBufferFIFO)
		{
			if(msg.timestamp > latestMessage)
				msgs.put(msg.toJSONObject());
		}
		return msgs.toString();
	}
	
}