package org.davidlindkvist.websocket;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.ResourceHandler;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

public class WebSocketServer 
{
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception 
	{
		Server server = new Server(8080);

		ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
		context.setContextPath("/");
		context.addServlet(new ServletHolder(new ChatServiceServlet()),"/service");
		context.addServlet(new ServletHolder(new SmartChatServiceServlet()),"/smartService");

		ResourceHandler rh = new ResourceHandler();
		rh.setDirectoriesListed(true);
		rh.setResourceBase("www");
		rh.setWelcomeFiles(new String[] {"index.html"});

		HandlerList handlers = new HandlerList();
		handlers.addHandler(rh);
		handlers.addHandler(context);

		server.setHandler(handlers);	        
		server.start();
		server.join();	
	}
}
